# rankedvote
Behindev Task 1 - Clone RankedVote.co website
